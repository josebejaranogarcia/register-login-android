package com.ilerna.pac_uf2_bejaranojose;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import android.widget.Toast;

public class Registro extends AppCompatActivity {

    EditText nombre, apellido, usuario, pass , email;
  //  Button btn_signUp;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_registro);
        nombre= findViewById(R.id.nombre);
        apellido= findViewById(R.id.apellido);
        usuario= findViewById(R.id.usuario);
        pass= findViewById(R.id.contrasenia);
        email= findViewById(R.id.email);
      //  btn_signUp = findViewById(R.id.signUp);
        //btn_signUp.setOnClickListener(this::signup);
    }

    /**
     * Metodo que se encarga de realizar el registro en la BD
     *
     * @info  El listener esta directamente en activity_registro.xml
     * android:onClick="signup"
     */
    public void signup(View v) {
        DatabaseDAO db = new DatabaseDAO(this, "pac_db", null, 1);
        if (db.insertData(nombre.getText().toString(),
                apellido.getText().toString(),
                usuario.getText().toString(),
                pass.getText().toString(),
                email.getText().toString())) {
            Toast.makeText(this, getString(R.string.regExito), Toast.LENGTH_SHORT).show();
            startActivity(new Intent(Registro.this, Login.class));
        } else
            Toast.makeText(this, getString(R.string.userExists), Toast.LENGTH_SHORT).show();
    }
}
